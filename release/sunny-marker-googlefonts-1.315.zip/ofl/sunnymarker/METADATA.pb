name: "Sunny Marker"
designer: "Sam Dunn"
license: "OFL"
category: "HANDWRITING"
date_added: "2026-09-17"
fonts {
  name: "Sunny Marker"
  style: "normal"
  weight: 400
  filename: "SunnyMarker[opsz,wdth,wght].ttf"
  post_script_name: "SunnyMarker-Regular"
  full_name: "Sunny Marker Regular"
  copyright: "Copyright 2026 The Sunny Marker Project Authors (https://github.com/samdunn/sunny-marker-font)"
}
fonts {
  name: "Sunny Marker"
  style: "italic"
  weight: 400
  filename: "SunnyMarker-Italic[opsz,wdth,wght].ttf"
  post_script_name: "SunnyMarker-Italic"
  full_name: "Sunny Marker Italic"
  copyright: "Copyright 2026 The Sunny Marker Project Authors (https://github.com/samdunn/sunny-marker-font)"
}
subsets: "latin"
subsets: "latin-ext"
subsets: "menu"
axes {
  tag: "opsz"
  min_value: 10.0
  max_value: 36.0
}
axes {
  tag: "wdth"
  min_value: 75.0
  max_value: 125.0
}
axes {
  tag: "wght"
  min_value: 300.0
  max_value: 700.0
}
source {
  repository_url: "https://github.com/samdunn/sunny-marker-font"
  files {
    source_file: "OFL.txt"
    dest_file: "OFL.txt"
  }
  files {
    source_file: "fonts/variable/SunnyMarker[opsz,wdth,wght].ttf"
    dest_file: "SunnyMarker[opsz,wdth,wght].ttf"
  }
  files {
    source_file: "fonts/variable/SunnyMarker-Italic[opsz,wdth,wght].ttf"
    dest_file: "SunnyMarker-Italic[opsz,wdth,wght].ttf"
  }
  files {
    source_file: "documentation/article/ARTICLE.en_us.html"
    dest_file: "article/ARTICLE.en_us.html"
  }
  files {
    source_file: "documentation/article/sunny-marker-specimen.png"
    dest_file: "article/sunny-marker-specimen.png"
  }
  files {
    source_file: "documentation/article/image-license.txt"
    dest_file: "article/image-license.txt"
  }
  branch: "main"
}
