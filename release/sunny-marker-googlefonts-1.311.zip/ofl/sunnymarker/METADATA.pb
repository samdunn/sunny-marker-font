name: "Sunny Marker"
designer: "Sam Dunn"
license: "OFL"
category: "HANDWRITING"
date_added: "2026-09-16"
fonts {
  name: "Sunny Marker"
  style: "normal"
  weight: 400
  filename: "SunnyMarker[opsz,slnt,wdth,wght].ttf"
  post_script_name: "SunnyMarker-Regular"
  full_name: "Sunny Marker Regular"
  copyright: "Copyright 2026 The Sunny Marker Project Authors (https://github.com/buildinternet/sunny-marker-font)"
}
subsets: "latin"
subsets: "latin-ext"
subsets: "menu"
axes {
  tag: "opsz"
  min_value: 10.0
  max_value: 36.0
}
axes {
  tag: "slnt"
  min_value: -9.0
  max_value: 0.0
}
axes {
  tag: "wdth"
  min_value: 75.0
  max_value: 125.0
}
axes {
  tag: "wght"
  min_value: 300.0
  max_value: 700.0
}
source {
  repository_url: "https://github.com/buildinternet/sunny-marker-font"
  branch: "main"
}
